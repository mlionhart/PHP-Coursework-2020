<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Problem 1</title>
</head>
<body>
    <?php
    // A function named putTogether that takes two parameters.
    // The function should take the two parameters, concatenate them together and then return the concatenated value. 
    function putTogether($string1, $string2) {
        return $string1 . $string2;
    }

    // Be sure to include the function and a line of PHP that calls the function with two parameters.
    echo putTogether("Mike ", "Hart");
    ?>
    
</body>
</html>
