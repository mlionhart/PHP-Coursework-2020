<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Problem 3</title>
</head>
<body>
    <?php
    // Explain the different between PHP functions isset() and empty(). Include your answers in the code from problems 1 and 2 as comments. Do not submit an answer you find on Google. Include some code snippets in your submission.

    /* ----------- Problem 3 Answers ------------ */
    
    // I'm not sure what you mean by including code snippets.  
    
    // These answers were straight from my week 1 notes - not from Google:

    // isset() checks to see if a variable is declared and not NULL.

    // empty() checks to see if variable is empty (examples of empty are: "", array(), and 0) 

    /* ----------- End of Problem 3 Answers ------------ */
    ?>
</body>
</html>