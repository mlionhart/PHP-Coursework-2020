<!DOCTYPE html>
<html lang="en">
<head>
    <title>Module 4 Skill Building Exercise No. 3</title>
    <link href="project.css" rel="stylesheet" type="text/css">
    <meta charset="utf-8" />
</head>
<body>
        <img src="banner.png" alt=""/>
    <div id="errors"><h2>There are 3 error(s) you must review</h2><p><b>Error people parameter not found:</b> A parameter to display the number of people to display.</p><p><b>Error avatars parameter not found:</b> A parameter to include or exclude avatars was not supplied. A value of "y" or "n" was expected.</p><p><b>Error bios parameter not found:</b> A parameter to include or exclude bios was not supplied. A value of "y" or "n" was expected.</p></div>
    <div id="wrapper">
        <div class="people">
            <!-- now display people, avatars and bios accordingly ONLY if there were no errors-->
                    </div><!-- end people div-->
    </div><!-- end wrapper div-->
</body>
</html>