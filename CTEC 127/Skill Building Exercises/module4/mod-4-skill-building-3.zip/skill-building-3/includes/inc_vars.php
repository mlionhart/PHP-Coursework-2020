<?php

$people = array("Joe Lagana","Gayle Ujifusa","Scott Fisher","Jeff Hendryx","Paul Yee","James Farrier","Marshall Pinder","Kelly Callahan","Allison Pierce","Erin Varner");

$avatars = array("malehead.png","femalehead.png","malehead.png","malehead.png","malehead.png","malehead.png","malehead.png","femalehead.png","femalehead.png","femalehead.png");

$bios = array("President & CEO / Laganatech","VP of Sales / Elguji Software","VP of Accounting / Drugco Inc.","Programmer / Mobile Solutions, Inc.","Systems Analyst / Sharp Systems","Systems Analyst / Sharp Systems","VP of Marketing / Sharp Systems","Lead Designer / Wry Toast Designs","Teacher / District 42","Student / EWU");

?>